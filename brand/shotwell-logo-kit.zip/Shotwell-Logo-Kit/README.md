# Shotwell — Logo Kit

Everything needed to place the Shotwell logo on a website, program, or slide.
**Prefer the SVG files.** They are resolution-independent and will stay sharp on
any display. Use PNG only where SVG isn't supported.

---

## Which file do I use?

| Situation | File |
|---|---|
| Light background (the default) | `SVG/shotwell-logo-horizontal.svg` |
| Dark background | `SVG/shotwell-logo-horizontal-white.svg` |
| One-color printing, faxes, engraving | `SVG/shotwell-logo-horizontal-black.svg` |
| Square space — avatar, favicon, app tile | `SVG/shotwell-mark.svg` |
| Sponsor wall / logo grid | `SVG/shotwell-logo-horizontal.svg` |

The horizontal lockup is the primary form. Use the mark on its own only where a
horizontal logo won't fit.

---

## Contents

```
SVG/
  shotwell-logo-horizontal.svg          Primary. Dark ink, orange flame.
  shotwell-logo-horizontal-black.svg    Single color, all dark ink.
  shotwell-logo-horizontal-white.svg    All white, for dark backgrounds.
  shotwell-mark.svg                     Lantern only. Dark ink, orange flame.
  shotwell-mark-black.svg               Lantern only, single color.
  shotwell-mark-white.svg               Lantern only, white.

PNG/                                    Transparent background.
  shotwell-logo-horizontal-{400,800,1600}w.png
  shotwell-logo-horizontal-black-{400,800,1600}w.png
  shotwell-logo-horizontal-white-{400,800,1600}w.png
  shotwell-mark-{256,512,1024}w.png
  shotwell-mark-black-{256,512,1024}w.png
  shotwell-mark-white-{256,512,1024}w.png

alternate-bold/                         Heavier-weight alternate. See below.
```

All PNGs have transparent backgrounds. Pick a width at least **2x** the size
you'll display it at, so it stays sharp on high-resolution screens.

---

## Colors

| | Hex | Where |
|---|---|---|
| Ink | `#2A2A32` | The line work and wordmark |
| Ember | `#C96E2D` | The flame only |
| White | `#FFFFFF` | Reversed version on dark backgrounds |

The flame is the only part of the logo that carries color.

---

## Clear space

Keep empty space around the logo equal to **half the height of the lantern** on
all sides. Nothing else — text, rules, other logos, photo edges — should enter
that margin.

---

## Minimum sizes

| Asset | Minimum |
|---|---|
| Horizontal lockup | 120 px wide (print: 32 mm) |
| Mark alone | 24 px wide (print: 8 mm) |

Below these, the lantern's fine lines start to break up. If you need the logo
smaller than the minimum, use the heavier version in `alternate-bold/`.

---

## Please don't

- Recolor it. Use the supplied black or white versions instead.
- Stretch or squash it. Scale proportionally.
- Rotate it, add a drop shadow, outline, or glow.
- Rebuild the wordmark in a different typeface.
- Place the standard version on a busy photo — use the white version on a dark
  overlay instead.
- Box it in or put it on a colored tile unless the tile is `#2A2A32` or white.

---

## About `alternate-bold/`

A heavier-weight drawing of the same lantern. It exists for situations where the
primary mark is too fine to survive: very small sizes, low-resolution screens,
embroidery, or printing where ink spreads. **Use the primary version unless one
of those applies.**

---

## Typeface

The wordmark is set in **Fraunces** (Regular, 400) and has been converted to
outlines — no font installation is required, and it will render identically
everywhere. Fraunces is licensed under the SIL Open Font License 1.1.

---

## Questions

Contact Shotwell before publishing if you need a variation that isn't in this
kit. We'd rather make you the right file than have you modify one of these.
